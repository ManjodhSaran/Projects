import React from 'react'
import Banner from '../components/Banner'
import Features from '../components/Features'
import HomeCards from '../components/HomeCards'
import Navbar from '../components/Navbar'
import Partner from '../components/Partner'
import '../styles/Home.scss'
const Home = () => {
    return (
        <div className="home">
            <Navbar />
            <Banner />
            <Partner />
            <Features />
            <HomeCards />
        </div>
    )
}

export default Home
