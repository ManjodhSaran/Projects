import React from 'react'
import '../../styles/FeaturesCard.scss'
const FeaturesCard = ({ title, icon, desc }) => {
    return (
        <div className="featuresCard">
            {icon}
            <h3>{title}</h3>
            <p>{desc}</p>
        </div>
    )
}

export default FeaturesCard
