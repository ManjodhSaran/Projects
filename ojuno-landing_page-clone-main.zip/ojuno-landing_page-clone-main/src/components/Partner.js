import React from 'react'
import '../styles/Partner.scss'
const Partner = () => {
    return (
        <div className="partner">
            <h3>AS SEEN ON</h3>
            <img className="partner__img" src="https://cdn.onjuno.com/remittance/publicaation.svg" alt="brands" />
            <img className="partner__imgMobile" src="https://cdn.onjuno.com/remittance/publication-mobile.svg" alt="brands" />
        </div>
    )
}

export default Partner
