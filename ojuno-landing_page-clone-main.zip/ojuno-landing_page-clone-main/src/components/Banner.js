import React from 'react'
import MailOutlineIcon from '@material-ui/icons/MailOutline';
import FDIOLogo from '../assets/images/FDIO.png'
import '../styles/Banner.scss'

const Banner = () => {
    return (
        <div className="banner">
            <div className="banner__left">
                <h1>Banking on the go</h1>
                <h3>Earn 1.20% on Deposits & 5% Cashback</h3>
                <h4>A modern checking account for hard working professionals that provides higher savings, faster support and peace of mind.</h4>
                <div className='banner__sub'>
                    <MailOutlineIcon />
                    <input placeholder="Enter Email Address" />
                    <button className="myButton myButton__filled">Apply Now</button>
                </div>
                <div className='banner__FDIO'>
                    <img src={FDIOLogo} alt="" />
                    <div>
                        <p>Banking services provided by</p>
                        <p>Evolve Bank & Trust; Member FDIC</p>
                    </div>
                </div>
            </div>
            <img src="https://cdn.onjuno.com/home/landing_hero_image.png" alt="demo__app" />
        </div>
    )
}

export default Banner
