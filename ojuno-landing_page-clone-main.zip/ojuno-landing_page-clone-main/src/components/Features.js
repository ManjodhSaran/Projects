import React from 'react'

import VerifiedUserOutlinedIcon from '@material-ui/icons/VerifiedUserOutlined';
import LanguageOutlinedIcon from '@material-ui/icons/LanguageOutlined';
import PhoneAndroidOutlinedIcon from '@material-ui/icons/PhoneAndroidOutlined';

import FeaturesCard from './cards/FeaturesCard';

const Features = () => {
    return (
        <div className="features">
            <div>
                <FeaturesCard
                    title="No Credit Checks"
                    icon={<VerifiedUserOutlinedIcon fontSize="large" className="featuresCard__icon" />}
                    desc="Opening an account does not affect your credit score"
                />
                <FeaturesCard
                    title="Immigrant Friendly"
                    icon={<LanguageOutlinedIcon fontSize="large" className="featuresCard__icon" />}
                    desc="Open an account in under 5 mins with SSN and Passport"
                />
                <FeaturesCard
                    title="Contactless"
                    icon={<PhoneAndroidOutlinedIcon fontSize="large" className="featuresCard__icon" />}
                    desc="Use a virtual card instantly with Apple Pay® and Google Pay®"
                />
            </div>
        </div>
    )
}

export default Features
