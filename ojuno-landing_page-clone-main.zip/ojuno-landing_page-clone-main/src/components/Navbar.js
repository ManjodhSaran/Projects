import { IconButton } from '@material-ui/core'
import React, { useRef, useState } from 'react'
import MenuOutlinedIcon from '@material-ui/icons/MenuOutlined';
import CloseIcon from '@material-ui/icons/Close';
import '../styles/Navbar.scss'
import { useEffect } from 'react';
import MenuCard from './MenuCard';

const Navbar = () => {
    const [show, setShow] = useState(false);
    const [scrollDown, setScrollDown] = useState(false);

    const scrollActive = () => {
        if (window.scrollY > 100) {
            setScrollDown(true);
        } else {
            setScrollDown(false);
        }
    }
    useEffect(() => {
        window.addEventListener("scroll", scrollActive);
        return () => window.removeEventListener("srcoll", scrollActive);
    }, [])

    const wrapperRefHeader = useRef(null);
    useOutsideAlerter(wrapperRefHeader);
    function useOutsideAlerter(ref) {
        useEffect(() => {
            function handleClickOutside(event) {
                if (ref.current && !ref.current.contains(event.target)) {
                    window.innerWidth < 1000 && setShow(false);
                }
            }
            document.addEventListener("mousedown", handleClickOutside);
            return () => document.removeEventListener("mousedown", handleClickOutside);
        }, [ref]);
    }

    return (
        <div ref={wrapperRefHeader} className={`navbar ${scrollDown && "navbar--scrollDown"}`}>
            <div className="navbar__content">
                <img className="navbar__logo" src="https://cdn.onjuno.com/on-juno.png" alt="onjunu" />
                <IconButton onClick={() => setShow(!show)} className="navbar__menuIcon">
                    {!show ? <MenuOutlinedIcon /> : <CloseIcon />}
                </IconButton>
                <div className={`navbar__nav ${show && 'navbar__nav--show'}`}>
                    <div className="nav__item nav--active"><p>Home</p></div>
                    <div className="nav__item ">
                        <MenuCard
                            id="Immigrants"
                            title="Immigrants"
                            list={[
                                { name: 'International Money Transfer', to: '/' },
                                { name: 'International Professionals', to: '/' },
                            ]}
                        />
                    </div>
                    <div className="nav__item ">
                        <MenuCard
                            id="Company"
                            title="Company"
                            list={[
                                { name: 'About', to: '/' },
                                { name: 'Newsroom', to: '/' },
                                { name: 'Careers', to: '/' },
                            ]}
                        />
                    </div>
                    <div className="nav__item ">
                        <MenuCard
                            id="Learn"
                            title="Learn"
                            list={[
                                { name: 'Blog', to: '/' },
                                { name: 'Guides', to: '/' },
                                { name: 'Help Center', to: '/' },
                            ]}
                        />
                    </div>
                    <div className="nav__item ">
                        <MenuCard
                            id="Resources"
                            title="Resources"
                            list={[
                                { name: 'Savings Calculator ', to: '/' },
                                { name: 'Compound Interest Calculator', to: '/' },
                                { name: 'Compare Interest Rates', to: '/' },
                            ]}
                        />
                    </div>
                    <div className="nav__item "><button className="myButton myButton__outlined">Login</button></div>
                    <div className="nav__item "><button className="myButton myButton__filled">Get Started</button></div>
                </div>
            </div>
        </div>
    )
}

export default Navbar
