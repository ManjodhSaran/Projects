import React from 'react';

import CheckCircleIcon from '@material-ui/icons/CheckCircle';
import InfoOutlinedIcon from '@material-ui/icons/InfoOutlined';

import '../styles/HomeCards.scss'

const HomeCards = () => {
    return (
        <div className="homeCards">
            <div className="homeCards__card">
                <div className="homeCards__cardImage homeCards__cardImage1">
                    <img src="https://cdn.onjuno.com/home/bonus-section-image.jpg" alt="web__image" />
                    <h3>+$125</h3>
                    <p>Bonus Earned</p>
                </div>
                <div className="homeCards__cardContent homeCards__cardContent1">
                    <h1>Earn 1.20% Bonus on Your Checking Account</h1>
                    <h3>You work hard to earn your paycheck, we work harder to make it grow faster.</h3>
                    <h4><CheckCircleIcon className="homeCards__cardContentIcon" />No Minimum Balance</h4>
                    <h4><CheckCircleIcon className="homeCards__cardContentIcon" />No Hidden Fees</h4>
                    <h4><CheckCircleIcon className="homeCards__cardContentIcon" />Withdraw Money Anytime</h4>
                    <button className="myButton myButton__filled">Apply Now</button>
                    <p><InfoOutlinedIcon className="homeCards__cardContentIcon color-grey" />Bonus Rate Disclosure</p>
                </div>
            </div>
            <div className="homeCards__card homeCards__card--reverse">
                <div className="homeCards__cardContent homeCards__cardContent2">
                    <h1>5% Cashback With Our Premium Metal Card</h1>
                    <h3>Choose 5 brands to earn 5% cashback - be it shopping at Walmart or riding with Uber, you decide!</h3>
                    <img src="https://cdn.onjuno.com/home/nri-brand-logos.png" alt="web__image" />
                    <button className="myButton myButton__filled">Apply Now</button>
                    <p><InfoOutlinedIcon className="homeCards__cardContentIcon color-grey" />Cashback Disclosure</p>
                </div>
                <div className="homeCards__cardImage homeCards__cardImage2">
                    <img src="https://cdn.onjuno.com/home/cashback-section-with-info-image.jpg" alt="web__image" />
                    <h3>+$10.99</h3>
                    <p>Cashback from <img src="https://cdn.onjuno.com/amazon.svg" className="amazon--image" alt="web__image" /></p>
                </div>

            </div>
        </div>
    )
}

export default HomeCards
