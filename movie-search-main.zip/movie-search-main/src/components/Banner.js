import React, { useEffect, useState } from 'react'

const Banner = ({ imageId }) => {
    const [background, setBackground] = useState("https://s3-us-west-2.amazonaws.com/flx-editorial-wordpress/wp-content/uploads/2018/03/13153742/RT_300EssentialMovies_700X250.jpg");
    useEffect(() => {
        imageId && setBackground(`https://image.tmdb.org/t/p/w500${imageId}`)
    }, [imageId]);
    return (
        <div className={`banner`} >
            <div className={`banner__container ${imageId && "banner-opacity"}`} style={{ backgroundImage: `url('${background}')` }}>
            </div>
        </div>
    )
}

export default Banner
