import React from 'react'
import { useState } from 'react'
import BackspaceOutlinedIcon from '@material-ui/icons/BackspaceOutlined';
import '../styles/OSK.scss'

const OSK = ({ query, setQuery, searchQuery }) => {
    const alpabets = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z', '-', '`']
    const numeric = ['1', '2', '3', '&', '#', '(', ')', '4', '5', '6', '@', '!', '?', ':', '7', '8', '9', '0', '.', '_', '"',]
    const [isNumeric, setIsNumeric] = useState(false);

    return (
        <div className='osk'>
            <div className="osk__top">
                <div className="osk__left">
                    {!isNumeric
                        ?
                        alpabets.map(char => <button onClick={e => setQuery(query + e.target.innerHTML)} key={char}>{char}</button>)
                        :
                        numeric.map(num => <button onClick={e => setQuery(query + e.target.innerHTML)} key={num}>{num}</button>)
                    }
                </div>
                <div className="osk__right">
                    <button onClick={() => setQuery(query.slice(0, -1))}><BackspaceOutlinedIcon className='osk__rightIcon' /></button>
                    <button onClick={() => setIsNumeric(!isNumeric)}>{isNumeric ? '123' : '& ABC'}</button>
                </div>
            </div>
            <div className="osk__bottom">
                <button onClick={() => setQuery(query + " ")}>space</button>
                <button onClick={() => setQuery('')}> clear</button>
                <button onClick={() => searchQuery(query)} disabled={!query}>search</button>
            </div>
        </div>
    )
}

export default OSK
