import React from 'react'
import KeyboardBackspaceOutlinedIcon from '@material-ui/icons/KeyboardBackspaceOutlined';
import CloseRoundedIcon from '@material-ui/icons/CloseRounded';
import { IconButton } from '@material-ui/core';

const SearchHeader = () => {
    return (
        <div className="search__header">
            <IconButton onClick={() => window.history.back()} className="search__iconButton">
                <KeyboardBackspaceOutlinedIcon className="search__icon" />
            </IconButton>
            <IconButton onClick={() => window.history.back()} className="search__iconButton">
                <CloseRoundedIcon className="search__icon" />
            </IconButton>
        </div>
    )
}

export default SearchHeader
