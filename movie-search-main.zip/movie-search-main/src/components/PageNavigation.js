import React from 'react';
import { makeStyles } from '@material-ui/core/styles';
import Pagination from '@material-ui/lab/Pagination';

const useStyles = makeStyles(() => ({
    ul: {
        "& .MuiPaginationItem-root": {
            color: "#fff"
        }
    }
}));
export default function PageNavigation({ count, onChange }) {
    const classes = useStyles();
    return (
        <div className={classes.root}>
            <Pagination
                classes={{ ul: classes.ul }}
                count={count}
                color="secondary"
                onChange={(e, page) => onChange(page)}

            />
        </div>
    );
}