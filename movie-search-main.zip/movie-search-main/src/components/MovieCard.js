import React from 'react'
import { useHistory } from 'react-router-dom';
import '../styles/MovieCard.scss'

const MovieCard = ({ movie }) => {
    const history = useHistory();
    const handleClick = () => {
        history.push(`/movie/${movie.id}/${movie.original_title}`)
    }
    const imgSrc = (movie.backdrop_path || movie.poster_path) ?
        `https://image.tmdb.org/t/p/w500/${movie.backdrop_path || movie.poster_path}`
        : 'https://st4.depositphotos.com/14953852/24787/v/600/depositphotos_247872612-stock-illustration-no-image-available-icon-vector.jpg'
    return (
        <div onClick={handleClick} className='movieCard'>
            <img
                src={imgSrc}
                alt={movie.original_title}
                title={movie.original_title}
            />
            <h4>{movie.original_title || movie.title} ({movie.original_language})</h4>
        </div>

    )
}

export default MovieCard
