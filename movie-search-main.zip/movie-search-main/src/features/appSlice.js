import { createSlice } from '@reduxjs/toolkit';

export const appSlice = createSlice({
  name: 'app',
  initialState: {
    recentSearch: [],
  },
  reducers: {
    setRecentSearch: (state, action) => {
      state.recentSearch = action.payload;
    },
  },
});

export const { setRecentSearch } = appSlice.actions;

export const selectRecentSearch = state => state.app.recentSearch;

export default appSlice.reducer;