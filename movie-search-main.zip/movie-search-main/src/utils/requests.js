const API_KEY = '2260586fb0e5e8267be6ea8854149076';

const requests = {
    fetchTrending: `/trending/all/week?api_key=${API_KEY}&language=en-US`,
    fetchNetflixOriginals: `/discover/tv?api_key=${API_KEY}&with_network=213`,
    fetchTopRated: `/movie/top_rated?api_key=${API_KEY}&language=en-US`,
    fetchActionRated: `/discover/movie?api_key=${API_KEY}&with_genres=28`,
    fetchComedyMovies: `/discover/movie?api_key=${API_KEY}&with_genres=35`,
    fetchHorrorMovies: `/discover/movie?api_key=${API_KEY}&with_genres=27`,
    fetchRomanceMovies: `/discover/movie?api_key=${API_KEY}&with_genres=10749`,
    fetchDocumentaries: `/discover/movie?api_key=${API_KEY}&with_genres=99`,
    fetchLatest: `/movie/latest?api_key=${API_KEY}&with_genres=99`,
    fetchUpComing: `/movie/upcoming?api_key=${API_KEY}&with_genres=99`,
    fetchGenreList: `/genre/movie/list?api_key=${API_KEY}&language=en-US`,
    fetchByGenre: `/discover/movie?api_key=${API_KEY}&language=en-US&with_genres=`,
    fetchByMovie: `?api_key=${API_KEY}&language=en-US`,
    fetchResult: `/search/movie?api_key=${API_KEY}`
}

export default requests;