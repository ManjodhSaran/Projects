import axios from '../utils/axios';
import React, { useEffect, useState } from 'react'
import requests from '../utils/requests';
import '../styles/MovieById.scss'
import { useParams } from 'react-router-dom';
import MovieTrailer from 'movie-trailer';
import Banner from '../components/Banner';

function runTime(min) {
    const num = min;
    const hours = (num / 60);
    const rhours = Math.floor(hours);
    const minutes = (hours - rhours) * 60;
    const rminutes = Math.round(minutes);
    return rhours + "h " + rminutes + "m";
}

const MovieById = () => {
    const { id, title } = useParams()
    const [data, setData] = useState([]);

    const [trailerUrl, setTrailerUrl] = useState("");

    useEffect(() => {
        async function fetchData() {
            const request = await axios.get(`/movie/${id}${requests.fetchByMovie}`);
            setData(request.data)
            return request;
        }
        id && fetchData();
        title && MovieTrailer(title).then(url => setTrailerUrl(url))
    }, [id, title])


    return (
        <div className="moviePage">
            <Banner className='movie__banner' imageId={data.backdrop_path} />
            <div className='movie__info'>
                <img className="info__image" src={`https://image.tmdb.org/t/p/w500/${data.poster_path || data.backdrop_path}`} alt="" />
                <div className='moviePage__right'>
                    <div className="info__all">
                        <h1>{data.original_title}</h1>
                        <h4>{data.overview}</h4>
                        {
                            data.tagline &&
                            <div className="tagline__container">
                                <h6 className="movie__tagline">{data.tagline}</h6>
                            </div>
                        }
                        <div className="genres">
                            {data.genres && data.genres.map(genre =>
                                <div key={genre.id} className="movie__genre" >
                                    <p>{genre.name}</p>
                                </div>)}
                        </div>
                        <h4>{runTime(data.runtime)}</h4>
                    </div>
                    <div className="imdb__container">
                        {
                            data.imdb_id &&
                            <a href={`https://www.imdb.com/title/${data.imdb_id}`} target="_blank" rel="noreferrer">
                                <img className="imdbLogo movie__logo" src="https://m.media-amazon.com/images/G/01/IMDb/BG_rectangle._CB1509060989_SY230_SX307_AL_.png" alt="" />
                            </a>
                        }
                        {
                            data.homepage &&
                            <a href={data.homepage} target="_blank" rel="noreferrer">
                                <img className="movie__logo" src="https://uploads-ssl.webflow.com/54fcefe421c2e6761cc51a4e/58a4e00e0732e3562fac11bd_homepage_logo.png" alt="" />
                            </a>
                        }
                        {
                            trailerUrl &&
                            <a href={trailerUrl} target="_blank" rel="noreferrer">
                                <img className="movie__logo" src="https://fuswork.files.wordpress.com/2014/11/trailer.png?w=517&h=174&crop=1" alt="" />
                            </a>
                        }


                    </div>
                </div>

            </div>

            {/* <Modal open={openModal} SetOpen={SetOpenModal} trailerUrl={trailerUrl} /> */}
        </div>
    )
}

export default MovieById
