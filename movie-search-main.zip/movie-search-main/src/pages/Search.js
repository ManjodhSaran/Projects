import React, { useState } from 'react'
import OSK from '../components/OSK'

import SearchRoundedIcon from '@material-ui/icons/SearchRounded';
import ReplayIcon from '@material-ui/icons/Replay';
import '../styles/Search.scss'

import CloseRoundedIcon from '@material-ui/icons/CloseRounded';
import SearchHeader from '../components/SearchHeader';
import { useDispatch, useSelector } from 'react-redux';
import { selectRecentSearch, setRecentSearch } from '../features/appSlice';
import { useHistory } from 'react-router-dom';

const Search = () => {
    const [query, setQuery] = useState('');
    const recentSearch = useSelector(selectRecentSearch);
    const dispatch = useDispatch();
    const history = useHistory();

    const clearRecents = () => {
        dispatch(setRecentSearch([]))
    }
    const searchQuery = (query) => {
        query && dispatch(setRecentSearch([query, ...recentSearch]))
        query && history.push(`/search/${query}`)
    }
    return (
        <div className="search">
            <SearchHeader />

            {/*  Search Bar*/}
            <form className='search__searchBar'>
                <SearchRoundedIcon className='search__searchBarIcon' />
                <input type='text' value={query} onChange={e => setQuery(e.target.value)} placeholder='Search' />
                <button type='submit' onClick={() => searchQuery(query)} hidden>submit</button>
            </form>

            <div className='search__inputs'>
                {/* Recent Search */}
                <div className="search__recents">
                    <div className="search__recentsHeader">
                        <h3>Recent Search Items </h3>
                        <CloseRoundedIcon onClick={clearRecents} />
                    </div>
                    <div className="search__recentsItems">
                        {recentSearch.map((item, i) =>
                            i < 5 &&
                            <div onClick={() => searchQuery(item)} key={item + i} className="search__recentsItem">
                                <ReplayIcon />
                                <p>{item}</p>
                            </div>)}
                    </div>
                </div>

                {/* on screen keyboard */}
                <OSK query={query} setQuery={setQuery} searchQuery={searchQuery} />

            </div>
        </div>
    )
}

export default Search
