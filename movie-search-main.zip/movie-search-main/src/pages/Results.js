import React, { useEffect, useState } from 'react'
import { useHistory, useParams } from 'react-router-dom'
import SearchHeader from '../components/SearchHeader'
import requests from '../utils/requests'
import axios from '../utils/axios'

import '../styles/Results.scss'
import PageNavigation from '../components/PageNavigation'
import MovieCard from '../components/MovieCard'
import { CircularProgress } from '@material-ui/core'

const Results = () => {
    const { query } = useParams();
    const [result, setResult] = useState([]);
    const [page, setPage] = useState(1);

    const history = useHistory();
    useEffect(() => {
        async function fetchData() {
            const request = await axios.get(`${requests.fetchResult}&query=${query}&page=${page}`);
            setResult(request.data);
            return request;
        }
        fetchData();

        !query && history.push('/search')
    }, [query, page]);

    const handlePageChange = (pageNo) => {
        setPage(pageNo)
    }

    return (
        <div className='results'>
            <SearchHeader />
            <div className="results__content">
                {result ?
                    (result.total_results !== 0 ?
                        <>
                            <h3>Search Results ( {result.total_results} )</h3>
                            <PageNavigation count={result.total_pages} onChange={handlePageChange} />

                            <div className="movie__cards">
                                {result.results && result.results.map(movie =>
                                    <MovieCard movie={movie} />
                                )}
                            </div>
                        </>
                        :
                        <>
                            <h3>No Result Found</h3>
                        </>
                    )
                    :
                    <CircularProgress color='secondary' />
                }
            </div>
        </div>
    )
}

export default Results
