import React from 'react';
import { BrowserRouter as Router, Switch, Route } from "react-router-dom";
import './App.css';
import Home from './pages/Home';
import MovieById from './pages/MovieById';
import Results from './pages/Results';
import Search from './pages/Search';

function App() {

  return (
    <div className="app">
      <Router>
        <Switch>
          <Route path="/search/:query">
            <Results />
          </Route>
          <Route path="/search">
            <Search />
          </Route>
          <Route path="/movie/:id/:title">
            <MovieById />
          </Route>
          <Route path="/">
            <Home />
          </Route>
        </Switch>
      </Router>
    </div>
  );
}

export default App;
