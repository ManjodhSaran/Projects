
/* Owl Carosel Main Banner*/

    $(document).ready(function() {
      $("#owl-demo-carosel").owlCarousel({

      navigation : true,
      slideSpeed : 300,
      paginationSpeed : 400,
      singleItem : true
      });
    });
	
/* Owl Carosel Main Banner*/


	
/* Owl Carosel Scroller Banner*/

    $(document).ready(function() {
      var owl = $("#owl-demo-full-1");
      owl.owlCarousel({              
        itemsCustom : [
          [0, 2],
          [450, 3],
          [600, 3],
          [800, 4],
          [1000, 4],
          [1200, 5],
          [1400, 5],
          [1600, 6]
        ],
        navigation : false
      });
    });

	
	
    $(document).ready(function() {
      var owl = $("#owl-demo-full-2");
      owl.owlCarousel({              
        itemsCustom : [
          [0, 2],
          [450, 3],
          [600, 3],
          [800, 4],
          [1000, 4],
          [1200, 5],
          [1400, 5],
          [1600, 6]
        ],
        navigation : false
      });
    });

	
	
    $(document).ready(function() {
      var owl = $("#owl-demo-full-3");
      owl.owlCarousel({              
        itemsCustom : [
         [0, 2],
          [450, 3],
          [600, 3],
          [800, 4],
          [1000, 4],
          [1200, 5],
          [1400, 5],
          [1600, 6]
        ],
        navigation : false
      });
    });
  
	
	
    $(document).ready(function() {
      var owl = $("#owl-demo-full-4");
      owl.owlCarousel({              
        itemsCustom : [
          [0, 2],
          [450, 3],
          [600, 3],
          [800, 4],
          [1000, 4],
          [1200, 5],
          [1400, 5],
          [1600, 6]
        ],
        navigation : false
      });
    });
   
/* Owl Carosel Scroller Banner*/