import { Paper } from '@material-ui/core'
import React from 'react'
import { useState } from 'react'
import '../styles/Calculator.scss'
import Header from './Header'
import Keyboard from './Keyboard'
import Screen from './Screen'

const Calculator = () => {
    const [num1, setNum1] = useState('');
    const [num2, setNum2] = useState('');
    const [operator, setOperator] = useState('');

    const clearScreen = () => {
        setNum1('');
        setNum2('');
        setOperator('');
    }

    const handleChange = (e) => {
        if (!operator) {
            setNum1(num1 + e.target.outerText)
        } else {
            setNum2(num2 + e.target.outerText)
        }
    }

    const handleOperatorChange = (e) => {
        if (!num2) {
            setOperator(e.target.outerText)
        } else {
            evaluate()
            setOperator(e.target.outerText)
        }

    }

    const evaluate = () => {

        const n1 = parseFloat(num1)
        const n2 = parseFloat(num2)

        switch (operator) {
            case '+':
                setNum1(n1 + n2)
                break;
            case '-':
                setNum1(n1 - n2)
                break;
            case '*':
                setNum1(n1 * n2)
                break;
            case '/':
                setNum1(n1 / n2)
                break;
            case '%':
                setNum1((n1 * n2) / 100)
                break;
        }

        setOperator('');
        setNum2('');

    }

    return (
        <Paper className='calculator' elevation={10} >
            <Header />
            <Screen
                output={`${num1}${operator}${num2}`}
            />
            <Keyboard
                setOperator={setOperator}
                handleChange={handleChange}
                clearScreen={clearScreen}
                evaluate={evaluate}
                handleOperatorChange={handleOperatorChange}
            />
        </Paper>

    )
}

export default Calculator
