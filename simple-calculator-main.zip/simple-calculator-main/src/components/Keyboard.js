import { Button, Paper } from '@material-ui/core'
import React from 'react'
import '../styles/Keyboard.scss'

const Keyboard = ({ handleChange, clearScreen, handleOperatorChange, evaluate }) => {
    const numerics = ['7', '8', '9', '4', '5', '6', '1', '2', '3', '0', '00', '.'];
    const operators = ['/', '*', '+', '-', '%'];

    return (
        <div className='keyboard'>

            <div className='keyboard__top'>
                <div className="keyboard__numeric">
                    {numerics.map(num =>
                        <Paper key={num} className="keyboard__key" elevation={3} onClick={handleChange}><p>{num}</p></Paper>
                    )}
                    <div className='keyboard__buttons'>
                        <Button variant="outlined" onClick={clearScreen}> Clear </Button>
                        <Button variant="contained" color="secondary" onClick={evaluate}> = </Button>
                    </div>
                </div>

                <div className="keyboard__actions">
                    {operators.map(num =>
                        <Paper key={num} className="keyboard__key" elevation={3} onClick={handleOperatorChange}><p>{num}</p></Paper>
                    )}
                </div>
            </div>


        </div>
    )
}

export default Keyboard
