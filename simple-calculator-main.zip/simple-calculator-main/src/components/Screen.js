import React from 'react'
import '../styles/Screen.scss'

const Screen = ({ output }) => {
    return (
        <div className="screen">
            <p>{output}</p>
        </div>
    )
}

export default Screen
