import React from 'react'
import '../styles/Header.scss'

const Header = () => {
    return (
        <div className='header'>
            <h2>Simple Calculator</h2>
        </div>
    )
}

export default Header
