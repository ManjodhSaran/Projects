import { Container } from '@material-ui/core';
import './App.css';
import Calculator from './components/Calculator';

function App() {
  return (
    <Container className="app" maxWidth="lg"  >
      <Calculator />
    </Container>

  );
}

export default App;
